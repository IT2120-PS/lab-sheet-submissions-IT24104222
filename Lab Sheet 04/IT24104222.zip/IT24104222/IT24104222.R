# Lab Exercise 4 - Descriptive Statistics
# Registration Number: IT24104222

# Set working directory
setwd("C:/Users/IT24104222/Desktop/IT24104222")

# 1. Import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
# Remove the first column which appears to be row numbers
branch_data <- branch_data[,-1]
# Rename columns to match expected names
names(branch_data) <- c("Sales_X1", "Advertising_X2", "Years_X3")

fix(branch_data)
attach(branch_data)

# 2. Identify variable types and scale of measurement
# Directly printing without cat
print("Variable Types and Scale of Measurement:")
print("Sales_X1: Quantitative Continuous, Ratio scale")
print("Advertising_X2: Quantitative Continuous, Ratio scale")
print("Years_X3: Quantitative Discrete, Ratio scale")

# 3. Boxplot for sales
boxplot(Sales_X1, main="Box Plot for Sales", outline=TRUE, outpch=8, horizontal=TRUE)

# 4. Five number summary and IQR for advertising
print("Five Number Summary for Advertising:")
summary(Advertising_X2)
print(paste("\nIQR for Advertising:", IQR(Advertising_X2), "\n"))

# 5. Function to find outliers
get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}

# Check for outliers in years variable
print("Checking for outliers in Years variable:")
get.outliers(Years_X3)

# Detach the dataset
detach(branch_data)


